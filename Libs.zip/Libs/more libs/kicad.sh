# kicad exports
# in ubuntu/debian linux, file should be linked to /etc/profile.d/kicad.sh
# mc 2/27/2014

export KIGITHUB=https://github.com/KiCad
export KISYSMOD=${HOME}/projects/kicad-lib/footprints
